﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace ArgumentReverser
{
    [TestClass]
    public class ReversingArgumentsTests
    {
        
    }
}
